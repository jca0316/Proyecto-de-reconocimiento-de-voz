<?php
    // Obtiene el valor de la variable $u desde la URL
    $u = $_GET['u'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VoiceWave</title>
    <link rel="stylesheet" href="css/index.css">
</head>
<body>
    
    
    <header>
        <h1>
        ReconocEncripta   
        </h1>
        <h2>Elige una de las siguientes opciones para comenzar</h2>
    </header>
    <?php echo "<h2 id='nombre'>Nombre del alumno: ".$u."</h2>"; ?>
    <div id="botones">
        <ul>
                <a href="alumno_grabar.php?u=".$u > 
                    <button type="button" id="but"> 
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span> Comenzar
                </button>
                </a>
                <a href="registro.php">
                    <button id="but" type="button">
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>Registrarte
                </button> </a>
                <a href="index.php">
                    <button id="but" type="button">
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>Inicio
                </button>
                </a>
                
            </ul>
    </div>
    
    <script src="js/comenzar.js"></script>
</body>
</html>
<?php
    function modificar($u,$p,$i){
        $c = mysqli_connect("localhost","root","","proyecto_pruebas");

        if($c){
            $strI = "update preguntas set pregunta='".$u."',respuesta=AES_ENCRYPT('". $p ."', 'software') where id='".$i."';";
            mysqli_query($c,$strI);

            //echo "Conectado al servidor y se puede registrar";
        }else{
            echo "No se pudo conectar";
        }

        mysqli_close($c);
    }
    if(isset($_POST["Mpregunta"]))
        modificar($_POST["Mpregunta"],$_POST["Mrespuesta"],$_POST["ID"]);

?>
<?php
    function listaUsuarios(){
        $strHTML="";
        $conn = mysqli_connect("localhost","root","","proyecto_pruebas");
        if($conn){
            //echo "conectado";
            $strQ = "SELECT id,pregunta,CAST(AES_DECRYPT(respuesta, 'software') AS CHAR) AS RECUPERADO FROM preguntas;";
            $r = $conn ->query($strQ);
            if($r->num_rows > 0){
                while($f = $r-> fetch_assoc()){
                    $strHTML .= "<br/><h4>"
                    .$f["id"]."-".$f["pregunta"]."---".$f["RECUPERADO"];
                    "</h4>";
                    
                }
            }else{
                $strHTML= " No hay registros";
            }
            //echo $r->num_rows;
        }
        else{
            echo "no se pudo conectar";
        }
        mysqli_close($conn);
        return $strHTML;
    }
    

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modificar</title>
    <link rel="stylesheet" href="css/ingresar.css">
    <link rel="stylesheet" href="css/index.css">   
</head>
<body>
<header>
        <ul>
            <h1>
            ReconocEncripta   
            </h1>
            <a href="admin.html">
                <button  >
                <span></span>
                <span></span>
                <span></span>
                <span></span>Volver
              </button> </a>
            <a href="index.php">
                <button  >
                <span></span>
                <span></span>
                <span></span>
                <span></span>Inicio
              </button>
            </a>
              
        </ul>
    </header>
    <main>
        <section>
            <article>
                <div id="preguntas2">
                    <h2>Preguntas registradas:</h2>
                    <?php
                        echo listaUsuarios()
                    ?>
                </div>
                
            </article>
        </section>
        <div id="agregar">
                <form  action="" method="post" >
                <span class="title">Ingresa la pregunta a modificar</span>
                <div>
                    <input placeholder="Ingresa tu pregunta" type="text" name="Mpregunta" id="Mpregunta">
                    <input placeholder="Ingresa la respuesta" type="text" name="Mrespuesta" id="Mrespuesta">
                    <input placeholder="Ingresa el numero" type="text" name="ID" id="ID">
                    <button>modificar</button>
                </div>
                </form>
            </div>
    </main>
    <footer>

    </footer>
    
</body>
</html>
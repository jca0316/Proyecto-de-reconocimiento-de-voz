create database proyecto_pruebas;
use proyecto_pruebas;

create table usuarios(
	user varchar(10) not null primary key
    ,password varchar(50) not null
);

create table administrador(
	user varchar(10) not null primary key
    ,password varchar(50) not null
);

CREATE TABLE preguntas (
    id int AUTO_INCREMENT,
    pregunta varchar(255) NOT NULL,
    respuesta varbinary(255) NOT NULL,
    PRIMARY KEY (id)
);

create table respuestas(
	respuesta varchar(100) not null 
);

create table calificaciones(
	nombre varchar(10) not null,
    calificacion int not null,
	fecha_actualizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP()
);

drop table calificaciones;

insert into calificaciones(nombre,calificacion) values('jorge',1);
        
INSERT INTO preguntas (pregunta, respuesta) VALUES ('¿De que color son las nubes?', AES_ENCRYPT('blancas', 'software'));
INSERT INTO preguntas (pregunta, respuesta) VALUES ('¿Que dia del mes se terminan las clase?', AES_ENCRYPT('19', 'software'));
INSERT INTO preguntas (pregunta, respuesta) VALUES ('¿En que mes es navidad?', AES_ENCRYPT('diciembre', 'software'));
INSERT INTO preguntas (pregunta, respuesta) VALUES ('¿Cual es el nombre de la estrella mas cercana a la tierra?', AES_ENCRYPT('sol', 'software'));
INSERT INTO preguntas (pregunta, respuesta) VALUES ('¿De que color es el cielo?', AES_ENCRYPT('Azul', 'software'));
INSERT INTO preguntas (pregunta, respuesta) VALUES ('¿Para que materia es este proyecto?', AES_ENCRYPT('para ingenieria en software y web', 'software'));
INSERT INTO preguntas (pregunta, respuesta) VALUES ('¿Cuál es el océano más grande del mundo?', AES_ENCRYPT('Océano Pacífico', 'software'));
INSERT INTO preguntas (pregunta, respuesta) VALUES ('¿Cuál es la montaña más alta del mundo?', AES_ENCRYPT('Monte Everest', 'software'));


insert into administrador(user,password)
values('admin','123');

insert into usuarios(user,password)
values('jr','123');


select * from usuarios;
select * from administrador;
SELECT * FROM preguntas ;
select * from respuestas;
select * from calificaciones;


SELECT iguales AS puntos
FROM (
    SELECT p.respuesta, 
           CASE WHEN AES_DECRYPT(p.respuesta, 'software') = r.respuesta THEN 1 ELSE 0 END AS iguales
    FROM preguntas p
    INNER JOIN respuestas r ON AES_DECRYPT(p.respuesta, 'software') = r.respuesta
) AS subconsulta;


/*este estoy usando*/
SELECT SUM(CASE WHEN AES_DECRYPT(p.respuesta, 'software') = r.respuesta THEN 1 ELSE 0 END) AS puntos_totales
FROM preguntas p
INNER JOIN respuestas r ON AES_DECRYPT(p.respuesta, 'software') = r.respuesta;



/*Ver respuestas de la tabla preguntas sin encriptación*/
SELECT CAST(AES_DECRYPT(respuesta, 'software') AS CHAR) AS RECUPERADO FROM preguntas;

/*Para ver el select con encripytación*/
SELECT pregunta, HEX(respuesta) AS encriptada FROM preguntas;

SELECT id,pregunta, HEX(respuesta) AS encriptada,CAST(AES_DECRYPT(respuesta, 'software') AS CHAR) AS RECUPERADO FROM preguntas;

/*update */
update preguntas set pregunta='¿Para que materia es este proyecto?',respuesta=AES_ENCRYPT('web', 'software') where id='3';


select count(*) as existe from usuarios where user='jorge' and password='0316';
select count(*) as valido from administrador where user='admin' and password='123';
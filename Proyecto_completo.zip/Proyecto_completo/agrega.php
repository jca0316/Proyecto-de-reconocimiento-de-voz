<?php
    function agregar($u, $p) {
        $c = mysqli_connect("localhost", "root", "", "proyecto_pruebas");
    
        if ($c) {
            // Encriptamos la respuesta
            $p_encriptada = password_hash($p, PASSWORD_BCRYPT);
            $strI = "insert into preguntas (pregunta, respuesta) values ('" . $u . "','" . $p_encriptada . "');";
            mysqli_query($c, $strI);
    
            // echo "Conectado al servidor y se puede registrar";
        } else {
            echo "No se pudo conectar";
        }
    
        mysqli_close($c);
    }
    
    if (isset($_POST["Apregunta"])) {
        agregar($_POST["Apregunta"], $_POST["Arespuesta"]);
    }
?>

<?php
    function listaUsuarios(){
        $strHTML="";
        $conn = mysqli_connect("localhost","root","","proyecto_pruebas");
        if($conn){
            //echo "conectado";
            $strQ = "select * from preguntas";
            $r = $conn ->query($strQ);
            if($r->num_rows > 0){
                while($f = $r-> fetch_assoc()){
                    $strHTML .= "<br/>"
                    .$f["pregunta"]."---".$f["respuesta"];;
                    
                }
            }else{
                $strHTML= " No hay registros";
            }
            //echo $r->num_rows;
        }
        else{
            echo "no se pudo conectar";
        }
        mysqli_close($conn);
        return $strHTML;
    }
    

?>
<?php
    function confirmar($w,$q){
        $cn = mysqli_connect("localhost","root","","proyecto_pruebas");

        if($cn){
            $strE = "insert into preguntas1 (pregunta,respuesta)  values('".$w."','".$q."');";
            mysqli_query($cn,$strE);

            //echo "Conectado al servidor y se puede registrar";
        }else{
            echo "No se pudo conectar";
        }

        mysqli_close($cn);
    }
    if(isset($_POST["Apregunta"]))
        confirmar($_POST["Apregunta"],$_POST["Arespuesta"]);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agregar</title>
    <link rel="stylesheet" href="css/ingresar.css">
    <link rel="stylesheet" href="css/index.css">  
    <link rel="stylesheet" href="css/forms.css"> 
</head>
<body>
<header>
        <ul>
            <h1>
                ReconocEncripta   
            </h1>
            <a href="admin.html">
                <button  >
                <span></span>
                <span></span>
                <span></span>
                <span></span>Volver
              </button> </a>
            <a href="index.php">
                <button  >
                <span></span>
                <span></span>
                <span></span>
                <span></span>Inicio
              </button>
            </a>
              
        </ul>
    </header>
    <main>
        <section>
            <article>
                <div id="preguntas">
                    <h2>Preguntas registradas:</h2>
                    <?php
                        echo listaUsuarios()
                    ?>
                </div>
                
            </article>
        </section>
        
            <div id="agregar">
                <form class="" action="agrega.php" method="post" >
                <span class="title">Ingresar nueva pregunta</span>
                <p class="description">Ingresa la nueva pregunta</p>
                <div>
                    <input placeholder="Ingresa tu pregunta" type="text" name="Apregunta" id="Apregunta">
                    <input placeholder="Ingresa la respuesta" type="text" name="Arespuesta" id="Arespuesta">
                    <button>Agregar</button>
                </div>
                </form>
            </div>
            
        
    </main>
    <footer>

    </footer>
    
</body>
</html>

<?php
function listaPreguntas(){
    $strHTML="";
    $conn = mysqli_connect("localhost","root","","proyecto_pruebas");
    if($conn){
        //echo "conectado";
        $strQ = "SELECT pregunta FROM preguntas1 ORDER BY rand() LIMIT 1;";
        $r = $conn ->query($strQ);
        if($r->num_rows > 0){
            $f = $r-> fetch_assoc();
            $strHTML .= "<h2>".$f["pregunta"]."</h2>";
        }else{
            $strHTML= " No hay registros";
        }
        //echo $r->num_rows;
    }
    else{
        echo "no se pudo conectar";
    }
    mysqli_close($conn);
    return $strHTML;
}

?>
<?php
function puntos(){
    $strHTML="";
    $conn = mysqli_connect("localhost","root","","proyecto_pruebas");
    if($conn){
        //echo "conectado";
        $strQ = "SELECT SUM(iguales) AS puntos_totales
        FROM (
            SELECT p.respuesta, 
                   CASE WHEN p.respuesta = r.respuesta THEN 1 ELSE 0 END AS iguales
            FROM preguntas1 p
            INNER JOIN respuestas r ON p.respuesta = r.respuesta
        ) AS subconsulta;
        ";
        $r = $conn ->query($strQ);
        if($r->num_rows > 0){
            $f = $r-> fetch_assoc();
            $strHTML .= "<h2>Puntos:".$f["puntos_totales"]."</h2>";
        }else{
            $strHTML= " No hay registros";
        }
        //echo $r->num_rows;
    }
    else{
        echo "no se pudo conectar";
    }
    mysqli_close($conn);
    return $strHTML;
}

?>

<?php
    function agregar($r){
        $c = mysqli_connect("localhost","root","","proyecto_pruebas");

        if($c){
            $strI = "insert into respuestas values('".$r."');";
            mysqli_query($c,$strI);
        }else{
            echo "No se pudo conectar";
        }

        mysqli_close($c);       
    }
    if(isset($_POST["texto"]))
        agregar($_POST["texto"]);

?>



</script>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VoiceWave</title>
    <link rel="stylesheet" href="css/ingresar.css">
    <link rel="stylesheet" href="css/index.css">    
    <link rel="stylesheet" href="css/inicio.css">  
</head>
<body>
    <header>
        <ul>
            <h1>
            ReconocEncripta   
            </h1>
            <a href="index.php">
                <button  >
                <span></span>
                <span></span>
                <span></span>
                <span></span>Inicio
              </button>
            </a>
            <a href="alumno.php">
                <button  >
                <span></span>
                <span></span>
                <span></span>
                <span></span>Terminar de grabar
              </button> </a>
            
        </ul>
    </header>
    <?php
    echo listaPreguntas()
    ?>
    <?php
    echo puntos()
    ?>

    <div id="centrar">
        <div class="botones">
        <button id="btnStartRecord">Empezar Grabación</button>
        <button id="btnStopRecord">Detener Grabación</button>
        </div>
        <form action="" method="post">
            <textarea type="texto" name="texto" id="texto" cols="50" rows="10" style="width: 519px; height: 93px;"></textarea>
            <button onclick="borrarTexto()" type="button">Borrar</button>
            <button onclick="agregarRespuesta()">Enviar</button>            
        </form>
        
    </div>
    <script src="grabar.js"></script>
    <script src="js/borrar.js"></script>

</body>
</html>
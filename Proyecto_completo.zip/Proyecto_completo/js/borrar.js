function borrarTexto(){
    document.getElementById("texto").value = "";
}

function cambiarPregunta(){
    var result ="<?php listaPreguntas(); ?>"
    document.write(result);
    }

function agregarRespuesta(){
    var result ="<?php agregar($u); >?";
    var result ="<?php agregar1($u); >?";
    var result ="<?php listaPreguntas(); >?";
    
}
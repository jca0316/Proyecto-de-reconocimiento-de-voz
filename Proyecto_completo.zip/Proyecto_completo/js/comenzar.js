function grabar(){
    document.getElementsByClassName("mydiv").style.display = "block";
}

function nombre(){
   var nombre= document.getElementsByClassName("txtU").value;
    var nombreEstudiante = nombre;
    document.write(nombreEstudiante);
}


    
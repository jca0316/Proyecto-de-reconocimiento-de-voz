create database proyecto_pruebas;
use proyecto_pruebas;

create table usuarios(
	user varchar(10) not null primary key
    ,password varchar(50) not null
);

create table administrador(
	user varchar(10) not null primary key
    ,password varchar(50) not null
);

create table preguntas(
	id int AUTO_INCREMENT,
	pregunta varchar(50) not null,
    respuesta varchar(50) not null,
    PRIMARY KEY (ID)
);

create table preguntas1(
	id int AUTO_INCREMENT,
	pregunta varchar(50) not null,
    respuesta varchar(50) not null,
    PRIMARY KEY (ID)
);
create table respuestas(
	respuesta varchar(50) not null 
);
drop table respuestas;


create table calificaciones(
	calificacion int not null,
    nombre varchar(10) not null,
    respuesta varchar(50) not null,
    fecha_actualizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP(),
    foreign key (nombre) references usuarios(user) ,
	foreign key (respuesta) references respuestas(respuesta)
    );
        

insert into preguntas (pregunta,respuesta) values('¿De que color es el cielo?','El cielo es azul');
insert into preguntas (pregunta,respuesta)  values('¿En que universidad estudias?','En la Universidad autonoma de guadalajara');
insert into preguntas (pregunta,respuesta)  values('¿Que año es?','2023');
insert into preguntas (pregunta,respuesta)  values('¿Para que materia es este proyecto?','Para ingenieria en software');

delete from preguntas where ID=1;
drop table preguntas;
insert into administrador(user,password)
values('admin','123');

insert into usuarios(user,password)
values('js','123');

select * from usuarios;
select * from administrador;
SELECT * FROM preguntas ;
select * from respuestas;
select * from calificaciones;

update preguntas set pregunta='jorge' where ID='1'

SELECT p.respuesta, r.respuesta
FROM preguntas p
INNER JOIN respuestas r ON p.respuesta = r.respuesta;

SELECT SUM(iguales) AS puntos_totales
FROM (
    SELECT p.respuesta, 
           CASE WHEN p.respuesta = r.respuesta THEN 1 ELSE 0 END AS iguales
    FROM preguntas p
    INNER JOIN respuestas r ON p.respuesta = r.respuesta
) AS subconsulta;

select count(*) as existe from usuarios where user='js' and password='123';
select count(*) as valido from administrador where user='admin' and password='123';
<?php
    function validar($u,$p){
        $strHTML="";
        $conn = mysqli_connect("localhost","root","","proyecto_pruebas");
        if($conn){
            //echo "conectado";
            $strQ = "select count(*) as existe from usuarios where user='".$u."' and password='".$p."';";
            $r = $conn ->query($strQ);
            if($r->num_rows > 0){
                $f = $r->fetch_assoc();
                echo $f["existe"];
                if($f["existe"] ==1){
                   header("Location: alumno.php?u=".$u); 
                }
                if($f["existe"] ==0){
                    header("Location: login.php"); 
                 }
            }
        }
        else{
            header("Location: login.php"); 
            $strHTML .= "<h2>Usuario o Contraseña incorrecta </h2>";
        }
        mysqli_close($conn);
    }
    if(isset($_POST["txtU"])){
        validar($_POST["txtU"],$_POST["txtP"]); 
    }
?>

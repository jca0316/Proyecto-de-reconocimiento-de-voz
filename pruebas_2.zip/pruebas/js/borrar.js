function borrarTexto() {
    document.getElementById("texto").value = "";
}

function cambiarPregunta(){
    var result ="<?php listaPreguntas(); ?>"
    document.write(result);
    }
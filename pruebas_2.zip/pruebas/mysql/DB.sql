create database proyecto_pruebas;

use proyecto_pruebas;

create table usuarios(
	user varchar(10) not null primary key
    ,password varchar(50) not null
);

create table administrador(
	user varchar(10) not null primary key
    ,password varchar(50) not null
);

create table preguntas(
	pregunta varchar(50) not null primary key
);

insert into preguntas values('¿Que es la programación orientada a objetos?');
insert into preguntas values('¿Que carrera estudias?');
insert into preguntas values('¿Cual es tu comida favorita?');
insert into preguntas values('¿Cual es tu deporte favorito?');

delete from preguntas where pregunta='¿cual es tu comida favorita?';

insert into administrador(user,password)
values('admin','123');

insert into usuarios(user,password)
values('js','123');

select * from usuarios;
select * from administrador;
select * from preguntas;
SELECT * FROM preguntas ORDER BY rand() LIMIT 1;

select count(*) as existe from usuarios where user='js' and password='123';
select count(*) as valido from administrador where user='admin' and password='123';
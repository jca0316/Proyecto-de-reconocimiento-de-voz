<?php
function listaPreguntas(){
    $strHTML="";
    $conn = mysqli_connect("localhost","root","","proyecto_pruebas");
    if($conn){
        //echo "conectado";
        $strQ = "SELECT * FROM preguntas ORDER BY rand() LIMIT 1;";
        $r = $conn ->query($strQ);
        if($r->num_rows > 0){
            $f = $r-> fetch_assoc();
            $strHTML .= "<h2>".$f["pregunta"]."</h2>";
        }else{
            $strHTML= " No hay registros";
        }
        //echo $r->num_rows;
    }
    else{
        echo "no se pudo conectar";
    }
    mysqli_close($conn);
    return $strHTML;
}
?>
<?php
    function agregar($u){
        $c = mysqli_connect("localhost","root","","proyecto_pruebas");

        if($c){
            $strI = "insert into respuestas values('".$u."');";
            mysqli_query($c,$strI);
        }else{
            echo "No se pudo conectar";
        }

        mysqli_close($c);
    }
    if(isset($_POST["texto"]))
        agregar($_POST["texto"]);

?>

</script>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VoiceWave</title>
    <link rel="stylesheet" href="css/ingresar.css">
    <link rel="stylesheet" href="css/index.css">    
    <link rel="stylesheet" href="css/inicio.css">  
</head>
<body>
    <header>
        <ul>
            <h1>
                VoiceWave   
            </h1>
            
            <a href="alumno.html">
                <button  >
                <span></span>
                <span></span>
                <span></span>
                <span></span>Terminar de grabar
              </button> </a>
            <a href="index.php">
                <button  >
                <span></span>
                <span></span>
                <span></span>
                <span></span>Inicio
              </button>
            </a>
              
        </ul>
    </header>
    <?php
    echo listaPreguntas()
    ?>
    <div id="centrar">
        <div class="botones">
        <button id="btnStartRecord">Empezar Grabación</button>
        <button id="btnStopRecord">Detener Grabación</button>
        </div>
        <form action="" method="post">
            <textarea type="texto" name="texto" id="texto" cols="50" rows="10" style="width: 519px; height: 93px;"></textarea>
            <button onclick="borrarTexto()">Borrar</button>
            <button >Enviar</button>
        </form>
        
    </div>
    
    <script src="grabar.js"></script>
    <script src="js/borrar.js"></script>

</body>
</html>
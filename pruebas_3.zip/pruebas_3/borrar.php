<?php
    function listaUsuarios(){
        $strHTML="";
        $conn = mysqli_connect("localhost","root","","proyecto_pruebas");
        if($conn){
            //echo "conectado";
            $strQ = "select * from preguntas";
            $r = $conn ->query($strQ);
            if($r->num_rows > 0){
                while($f = $r-> fetch_assoc()){
                    $strHTML .= "<br/>
                    <a id='links' href='borrar.php?u=".$f["pregunta"]."'>Eliminar Pregunta</a>"
                    .$f["pregunta"];
                }
            }else{
                $strHTML= " No hay registros";
            }
            //echo $r->num_rows;
        }
        else{
            echo "no se pudo conectar";
        }
        mysqli_close($conn);
        return $strHTML;
    }
    

?>
<?php
    function eliminar($u){
        $conn = mysqli_connect("localhost","root","","proyecto_pruebas");
        
        if($conn){
            $w = "delete from preguntas where pregunta = '".$u."';";
            $x= mysqli_query($conn,$w);
        }
        else{
            echo "fallo de conexión";
        }
        mysqli_close($conn);
        
    }
    if(isset($_GET["u"])){
        eliminar($_GET["u"]);
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Borrar</title>
    <link rel="stylesheet" href="css/ingresar.css">
    <link rel="stylesheet" href="css/index.css">   
</head>
<body>
<header>
        <ul>
            <h1>
                VoiceWave   
            </h1>
            <a href="admin.html">
                <button  >
                <span></span>
                <span></span>
                <span></span>
                <span></span>Volver
              </button> </a>
            <a href="index.php">
                <button  >
                <span></span>
                <span></span>
                <span></span>
                <span></span>Inicio
              </button>
            </a>
              
        </ul>
    </header>
    <main>
        <section>
            <article>
                <div id="exterior">
                    <div id="preguntas">
                        <h2>Preguntas registradas:</h2>
                        <?php
                            echo listaUsuarios()
                        ?>
                    </div>
                </div>
                
                
            </article>
        </section>
    </main>
    <footer>

    </footer>
    
</body>
</html>
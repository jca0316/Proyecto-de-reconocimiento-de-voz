<?php
    function agregar($u,$p){
        $c = mysqli_connect("localhost","root","","proyecto_pruebas");

        if($c){
            $strI = "insert into usuarios(user,password) values('".$u."','".$p."');";
            mysqli_query($c,$strI);

            //echo "Conectado al servidor y se puede registrar";
        }else{
            echo "No se pudo conectar";
        }

        mysqli_close($c);
    }
    if(isset($_POST["txtUsuario"]))
        agregar($_POST["txtUsuario"],$_POST["txtPassword"]);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro</title>
    <link rel="stylesheet" href="css/forms.css">
    <link rel="stylesheet" href="css/index.css">
    <link rel="stylesheet" href="css/ingresar.css">
</head>
<body>
<header>
    <h1>Registrate</h1>

        <a href="inicio.html" id="regreso">
            <button >
                <span></span>
                <span></span>
                <span></span>
                <span></span>Inicio
            </button>
        </a>
    </header>
    <main>
    <div class="login-box">
        <p>Registro</p>
        <p id="msg"></p>
        <form action="" method="post" name="fRegistro" id="flogin">
          <div class="user-box">
          <input type="text" name="txtUsuario" id="txtUsuario" placeholder="Usuario">
          </div>
          <div class="user-box">
          <input type="text" name="txtPassword" id="txtPassword" placeholder="Contraseña">
          </div>
            <button>
                Guardar
            </button>
        </form>
        <p>Ya estas registrado? <a href="login.php" class="a2">Inicia sesion</a></p>
      </div>
      
    </main>
</body>
</html>
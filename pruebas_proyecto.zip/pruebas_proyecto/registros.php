<?php
    function listaUsuarios(){
        $strHTML="";
        $conn = mysqli_connect("localhost","root","","productos13_v2");
        if($conn){
            //echo "conectado";
            $strQ = "select * from usuarios";
            $r = $conn ->query($strQ);
            if($r->num_rows > 0){
                while($f = $r-> fetch_assoc()){
                    $strHTML .= "<br/>".$f["user"]." ".$f["password"];
                }
            }else{
                $strHTML= " No hay registros";
            }
            //echo $r->num_rows;
        }
        else{
            echo "no se pudo conectar";
        }
        mysqli_close($conn);
        return $strHTML;
    }
    

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registros</title>
</head>
<body>
    <header>
    </header>
    <main>
        <section>
            <article>
                <h2>Usuarios registrados:</h2>
                <?php
                    echo listaUsuarios()
                ?>
            </article>
        </section>
    </main>
    <footer>

    </footer>
    
</body>
</html>
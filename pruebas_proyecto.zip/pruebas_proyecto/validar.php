<?php
    function validar($u,$p){
        $strHTML="";
        $conn = mysqli_connect("localhost","root","","proyecto_pruebas");
        if($conn){
            //echo "conectado";
            $strQ = "select count(*) as existe from usuarios where user='".$u."' and password='".$p."';";
            $r = $conn ->query($strQ);
            if($r->num_rows > 0){
                $f = $r->fetch_assoc();
                echo $f["existe"];
                if($f["existe"] ==1){
                   header("Location: alumno.html"); 
                }
                if($f["existe"] ==0){
                    header("Location: login.php"); 
                    $strHTML= " Usuario o Contraseña incorrecta";
                 }
            }
        }
        else{
            header("Location: login.php"); 
            echo "no conectado";
        }
        mysqli_close($conn);
    }
    if(isset($_POST["txtU"])){
        validar($_POST["txtU"],$_POST["txtP"]);
    }
    /*
    validar("js","");
    validar("","123");
    validar("js","123");
    validar("","");
    */
?>

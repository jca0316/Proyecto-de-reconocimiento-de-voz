<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="css/index.css">
    <link rel="stylesheet" href="css/inicio.css">
</head>
<body>
    <header>
        <h1>¿Eres alumno o Administrador?</h1>
        <div>
            Bienvenido, para poder continuar debes decirnos si eres un alumno que probara el programa o si eres un Administrador.
        </div>
    </header>
    <main>
        
        <article id="boton-index">
            <a href="login_admin.php">
                <button id="but">
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>Administrador
                </button>
            </a>
            <a href="login.php">
                <button id="but">
                <span></span>
                <span></span>
                <span></span>
                <span></span>Alumno
            </button>
            </a>
        </article>
        
        
    </main>
    <footer>

    </footer>
</body>
</html>
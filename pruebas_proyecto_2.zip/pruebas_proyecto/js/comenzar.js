function grabar(){
    document.getElementsByClassName("mydiv").style.display = "block";
}



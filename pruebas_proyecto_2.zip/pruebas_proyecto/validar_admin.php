<?php
    function validar($u,$p){
        $strHTML="";
        $conn = mysqli_connect("localhost","root","","proyecto_pruebas");
        if($conn){
            $strQ1 = "select count(*) as valido from administrador where user='".$u."' and password='".$p."';";
            $s = $conn ->query($strQ1);
            if($s->num_rows > 0){
                $d = $s->fetch_assoc();
                echo $d["valido"];
                if($d["valido"] ==1){
                   header("Location: admin.html"); 
                }
                if($d["valido"] ==0){
                    header("Location: login.php"); 
                    $strHTML= " Usuario o Contraseña incorrecta";
                }
            }
        }
        else{
            header("Location: login_admin.php"); 
            echo "no conectado";
        }
        mysqli_close($conn);
    }
    if(isset($_POST["txtU"])){
        validar($_POST["txtU"],$_POST["txtP"]);
    }
    /*
    validar("js","");
    validar("","123");
    validar("js","123");
    validar("","");
    */
?>
